"""AOS Protected Entrypoint Forwarder."""
from .entrypoint_impl import *
from .entrypoint_impl import main
if __name__ == "__main__":
    main()
