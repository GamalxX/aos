"""AOS Protected Entrypoint Forwarder."""
from .settings_service_impl import *
from .settings_service_impl import main
if __name__ == "__main__":
    main()
