"""AOS Protected Entrypoint Forwarder."""
from .mcp_server_impl import *
from .mcp_server_impl import main
if __name__ == "__main__":
    main()
