// ==========================================================================
// AOS Control Center — Frontend Script
// ==========================================================================

const API_BASE = window.location.origin.startsWith('http') ? window.location.origin : 'http://127.0.0.1:4141';
let currentModes = {};
let currentProvider = 'host';
let registeredProjects = [];
let selectedProjectPath = '';
let activeSnippetLang = 'python';
let activeReviewTab = 'md';
let currentLiveMission = null;
let providerSettingsCache = {};
let currentOllamaMode = 'local';
let isRawReviewMode = false;

// --------------------------------------------------------------------------
// 1. Tab Navigation
// --------------------------------------------------------------------------
function switchTab(tabId) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  
  const targetBtn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('onclick')?.includes(tabId));
  if (targetBtn) targetBtn.classList.add('active');

  const pane = document.getElementById('tab_' + tabId);
  if (pane) pane.classList.add('active');

  if (tabId === 'projects') {
    loadProjects();
  }
}

// --------------------------------------------------------------------------
// 2. Continuous Heartbeat (Watchdog Keeps Server Active)
// --------------------------------------------------------------------------
let isOfflineMode = false;

function setupPreviewMode() {
  if (isOfflineMode) return;
  isOfflineMode = true;

  const badge = document.getElementById('txtServerStatus');
  if (badge) badge.textContent = 'Preview Mode (Offline)';
  const pulse = document.getElementById('serverStatusBadge');
  if (pulse) pulse.style.color = 'var(--accent)';

  // 1. Setup Modes
  if (!currentModes || Object.keys(currentModes).length === 0) {
    currentModes = {
      assistant_llm_enabled: false,
      flowchart_generator: 'assistant_llm',
      review_generator: 'assistant_llm',
      developer_flowcharts: true,
      human_review_file: true,
      language_bridge: false,
      prompt_enhancer: false,
      comment_verbosity: 'professional_minimal'
    };
  }
  renderModesUI();

  // 2. Setup Host Preview
  populateHostModels({
    host_name: 'Google Antigravity',
    primary_model: 'Active Chat Model (Auto)',
    models: [
      { id: 'auto', label: 'Automatic Host Delegation (Session Default)', is_primary: false }
    ]
  });

  // 3. Setup Project Preview
  if (!registeredProjects || registeredProjects.length === 0) {
    registeredProjects = [
      {
        name: "aos",
        path: "D:\\Gamal\\agent\\aos",
        disk: { total_formatted: "1.42 MB", cache_formatted: "320 KB" },
        telemetry: {
          cumulative_tokens_saved: 42800,
          avg_savings_pct: 36.8,
          host_turns_spared: 15,
          host_protection_rate_pct: 75.0,
          runway_multiplier: 1.8
        },
        live_mission: {
          has_mission: true,
          mission_state: "completed",
          objective: "Surgical Patch & Telemetry Optimization (Sample Preview)",
          updated_at: new Date().toISOString(),
          progress_pct: 100,
          done_steps: 3,
          total_steps: 3,
          steps: [
            { index: 1, title: "Zero-Model Configuration Check", status: "completed", checkbox: "✓" },
            { index: 2, title: "Precision Slice Extraction & Analysis", status: "completed", checkbox: "✓" },
            { index: 3, title: "Surgical Patch & Regression Verification", status: "completed", checkbox: "✓" }
          ],
          human_markdown: "### Architectural Delta & Code Review\n\n- **Precision Patching**: Fixed boundary comparison in `should_allow_retry`\n- **Zero Token Drift**: Preserved AST layout through precision slices.\n- **Verification**: 100% test pass on first attempt with zero-model cache hits.",
          mermaid_flowchart: "flowchart TD\n    A[Task: Settlement Patch] --> B{AOS Precision Slicer}\n    B -->|Zero-Model Hit| C[Exact Slice]\n    C --> D[Worker Application]\n    D --> E[Verification Pass: 6/6]"
        }
      }
    ];
    renderProjectsList();
  }
}

function pingHeartbeat() {
  fetch(API_BASE + '/api/heartbeat')
    .then(r => r.json())
    .then(data => {
      const wasOffline = isOfflineMode;
      isOfflineMode = false;
      const badge = document.getElementById('txtServerStatus');
      if (badge) badge.textContent = `Online (127.0.0.1:${data.server_port || 4141})`;
      const pulse = document.getElementById('serverStatusBadge');
      if (pulse) pulse.style.color = 'var(--success)';
      if (wasOffline) {
        loadStatus();
        loadHostInfo();
        loadProjects();
      }
    })
    .catch(() => {
      setupPreviewMode();
    });
}
setInterval(pingHeartbeat, 4000);
pingHeartbeat();

function closeServerAndTab() {
  fetch(API_BASE + '/api/shutdown', { method: 'POST' }).finally(() => {
    window.close();
  });
}

// --------------------------------------------------------------------------
// 3. Load Modes & Status
// --------------------------------------------------------------------------
function loadStatus() {
  fetch(API_BASE + '/api/status')
    .then(r => r.json())
    .then(data => {
      currentModes = data.modes || {};
      renderModesUI();
      if (Array.isArray(data.all_providers)) {
        data.all_providers.forEach(p => {
          let cid = p.provider_id;
          if (cid === 'ollama_local' || cid === 'ollama_cloud') cid = 'ollama';
          providerSettingsCache[cid] = {
            model: p.model_name || '',
            endpoint: p.endpoint_url || '',
            key: p.api_key_masked || '',
            ollama_mode: p.provider_id === 'ollama_cloud' ? 'cloud' : 'local'
          };
        });
      }
      if (data.active_provider && data.active_provider.provider_id) {
        selectProvider(data.active_provider.provider_id);
        const nameInp = document.getElementById('txt_model_name');
        if (nameInp && data.active_provider.model_name) nameInp.value = data.active_provider.model_name;
        const urlInp = document.getElementById('txt_endpoint_url');
        if (urlInp && data.active_provider.endpoint_url) urlInp.value = data.active_provider.endpoint_url;
      } else {
        selectProvider('host');
      }
      updateDynamicSnippets();
    })
    .catch(e => {
      console.warn('Status fetch fallback:', e);
      selectProvider('host');
      setupPreviewMode();
    });
}

function renderModesUI() {
  const verb = currentModes.comment_verbosity || 'professional_minimal';
  document.querySelectorAll('.mode-card').forEach(c => c.classList.remove('active'));
  if (verb === 'zero_comments') document.getElementById('seg_zero')?.classList.add('active');
  else if (verb === 'verbose') document.getElementById('seg_verbose')?.classList.add('active');
  else document.getElementById('seg_minimal')?.classList.add('active');

  const astChk = document.getElementById('chk_assistant_enabled');
  if (astChk) astChk.checked = !!currentModes.assistant_llm_enabled;

  const flowChk = document.getElementById('chk_developer_flowcharts');
  if (flowChk) flowChk.checked = currentModes.developer_flowcharts !== false;

  const reviewChk = document.getElementById('chk_human_review');
  if (reviewChk) reviewChk.checked = currentModes.human_review_file !== false;

  const langChk = document.getElementById('chk_language_bridge');
  if (langChk) langChk.checked = !!currentModes.language_bridge;

  const enhChk = document.getElementById('chk_prompt_enhancer');
  if (enhChk) enhChk.checked = !!currentModes.prompt_enhancer;

  // Generator Sub-Options
  const flowGen = currentModes.flowchart_generator || 'assistant_llm';
  document.getElementById('pill_flow_assistant')?.classList.toggle('active', flowGen === 'assistant_llm');
  document.getElementById('pill_flow_primary')?.classList.toggle('active', flowGen === 'primary_llm');

  const revGen = currentModes.review_generator || 'assistant_llm';
  document.getElementById('pill_rev_assistant')?.classList.toggle('active', revGen === 'assistant_llm');
  document.getElementById('pill_rev_primary')?.classList.toggle('active', revGen === 'primary_llm');

  updateAssistantUIState();
}

function updateAssistantUIState() {
  const isEnabled = !!currentModes.assistant_llm_enabled;
  const banner = document.getElementById('assistant_disabled_banner');
  const body = document.getElementById('assistant_config_body');
  if (banner) banner.style.display = isEnabled ? 'none' : 'flex';
  if (body) {
    if (isEnabled) {
      body.classList.remove('is-disabled');
    } else {
      body.classList.add('is-disabled');
    }
  }
}

function setFlowchartGen(target) {
  currentModes.flowchart_generator = target;
  document.getElementById('pill_flow_assistant')?.classList.toggle('active', target === 'assistant_llm');
  document.getElementById('pill_flow_primary')?.classList.toggle('active', target === 'primary_llm');
  saveModes();
  showToast('Flowchart generator set to: ' + (target === 'primary_llm' ? 'Primary Model' : 'Assistant Model'));
}

function setReviewGen(target) {
  currentModes.review_generator = target;
  document.getElementById('pill_rev_assistant')?.classList.toggle('active', target === 'assistant_llm');
  document.getElementById('pill_rev_primary')?.classList.toggle('active', target === 'primary_llm');
  saveModes();
  showToast('Review generator set to: ' + (target === 'primary_llm' ? 'Primary Model' : 'Assistant Model'));
}

function setCommentMode(mode) {
  currentModes.comment_verbosity = mode;
  renderModesUI();
  saveModes();
}

function saveModes() {
  const flowChk = document.getElementById('chk_developer_flowcharts');
  if (flowChk) currentModes.developer_flowcharts = flowChk.checked;

  const reviewChk = document.getElementById('chk_human_review');
  if (reviewChk) currentModes.human_review_file = reviewChk.checked;

  const langChk = document.getElementById('chk_language_bridge');
  if (langChk) currentModes.language_bridge = langChk.checked;

  const enhChk = document.getElementById('chk_prompt_enhancer');
  if (enhChk) currentModes.prompt_enhancer = enhChk.checked;

  currentModes.context_compression_enabled = true; // Core invariant
  currentModes.perf_complexity_sentinel = true;    // Core invariant

  fetch(API_BASE + '/api/save_modes', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(currentModes)
  }).then(() => showToast('Preferences saved.'));
}

function toggleAssistantMaster() {
  const chk = document.getElementById('chk_assistant_enabled');
  currentModes.assistant_llm_enabled = chk ? chk.checked : true;
  updateAssistantUIState();
  saveModes();
}

// --------------------------------------------------------------------------
// 4. Provider Selection & Model Discovery (Isolated Per Provider)
// --------------------------------------------------------------------------
function selectProvider(pId) {
  let cleanId = pId;
  if (pId === 'ollama_local' || pId === 'ollama_cloud') cleanId = 'ollama';

  // Save current external provider inputs to prevent data bleeding
  if (currentProvider && currentProvider !== 'host') {
    const mName = document.getElementById('txt_model_name')?.value || '';
    const mUrl = document.getElementById('txt_endpoint_url')?.value || '';
    const mKey = document.getElementById('txt_api_key')?.value || '';
    providerSettingsCache[currentProvider] = {
      model: mName,
      endpoint: mUrl,
      key: mKey,
      ollama_mode: currentOllamaMode
    };
  }

  currentProvider = cleanId;

  document.querySelectorAll('.provider-pill').forEach(p => p.classList.remove('active'));
  const btn = document.getElementById('tab_' + cleanId) || 
    Array.from(document.querySelectorAll('.provider-pill')).find(p => p.getAttribute('onclick')?.includes(cleanId));
  if (btn) btn.classList.add('active');

  const hostPanel = document.getElementById('panel_host');
  const extPanel = document.getElementById('panel_external');
  const keyGroup = document.getElementById('group_api_key');
  const urlInput = document.getElementById('txt_endpoint_url');
  const nameInput = document.getElementById('txt_model_name');
  const keyInput = document.getElementById('txt_api_key');
  const ollamaModeRow = document.getElementById('ollama_connection_mode_row');
  const testFb = document.getElementById('test_feedback');
  if (testFb) testFb.style.display = 'none';

  if (cleanId === 'host') {
    if (hostPanel) hostPanel.style.display = 'block';
    if (extPanel) extPanel.style.display = 'none';
    loadHostInfo();
    return;
  }

  if (hostPanel) hostPanel.style.display = 'none';
  if (extPanel) extPanel.style.display = 'block';

  // Restore isolated cache or pristine provider defaults
  const cached = providerSettingsCache[cleanId];

  if (cleanId === 'ollama') {
    if (ollamaModeRow) ollamaModeRow.style.display = 'block';
    const mode = cached?.ollama_mode || (pId === 'ollama_cloud' ? 'cloud' : 'local');
    setOllamaConnectionMode(mode, false);
    if (cached) {
      if (nameInput) nameInput.value = cached.model;
      if (urlInput) urlInput.value = cached.endpoint;
      if (keyInput) keyInput.value = cached.key;
    } else {
      if (nameInput) nameInput.value = '';
      if (urlInput) urlInput.value = (mode === 'cloud') ? 'https://ollama.com/v1' : 'http://localhost:11434';
      if (keyInput) keyInput.value = '';
    }
  } else {
    if (ollamaModeRow) ollamaModeRow.style.display = 'none';
    if (keyGroup) keyGroup.style.display = 'block';

    if (cached) {
      if (nameInput) nameInput.value = cached.model;
      if (urlInput) urlInput.value = cached.endpoint;
      if (keyInput) keyInput.value = cached.key;
    } else {
      if (nameInput) nameInput.value = '';
      if (keyInput) keyInput.value = '';
      if (cleanId === 'lm_studio') {
        if (urlInput) {
          urlInput.value = 'http://localhost:1234/v1';
          urlInput.placeholder = 'http://localhost:1234/v1';
        }
      } else if (cleanId === 'vllm') {
        if (urlInput) {
          urlInput.value = 'http://localhost:8000/v1';
          urlInput.placeholder = 'http://localhost:8000/v1';
        }
      } else if (cleanId === 'openrouter') {
        if (urlInput) urlInput.value = 'https://openrouter.ai/api/v1';
      } else if (cleanId === 'groq') {
        if (urlInput) urlInput.value = 'https://api.groq.com/openai/v1';
      } else if (cleanId === 'deepseek') {
        if (urlInput) urlInput.value = 'https://api.deepseek.com/v1';
      } else if (cleanId === 'gemini') {
        if (urlInput) urlInput.value = 'https://generativelanguage.googleapis.com/v1beta/openai';
      } else if (cleanId === 'custom_openai') {
        if (urlInput) urlInput.value = 'https://api.openai.com/v1';
      }
    }
  }

  updateDynamicSnippets();
  refreshCurrentProviderModels();
}

let activeModelFetchAbortController = null;

function setOllamaConnectionMode(mode, refresh = true) {
  currentOllamaMode = mode;
  const btnLocal = document.getElementById('btn_conn_local');
  const btnCloud = document.getElementById('btn_conn_cloud');
  const keyGroup = document.getElementById('group_api_key');
  const hint = document.getElementById('ollama_mode_hint');
  const urlInput = document.getElementById('txt_endpoint_url');

  if (mode === 'local') {
    if (btnLocal) btnLocal.classList.add('active');
    if (btnCloud) btnCloud.classList.remove('active');
    if (keyGroup) keyGroup.style.display = 'none';
    if (hint) hint.textContent = 'Runs against your background local daemon (localhost:11434). No API key required.';
    if (urlInput) {
      urlInput.placeholder = 'http://localhost:11434';
      if (!urlInput.value || urlInput.value.includes('ollama.com')) {
        urlInput.value = 'http://localhost:11434';
      }
    }
  } else {
    if (btnLocal) btnLocal.classList.remove('active');
    if (btnCloud) btnCloud.classList.add('active');
    if (keyGroup) keyGroup.style.display = 'block';
    if (hint) hint.textContent = 'Runs against Ollama Cloud (https://ollama.com/v1) or your remote Ollama endpoint. Enter your API key.';
    if (urlInput) {
      urlInput.placeholder = 'https://ollama.com/v1';
      if (!urlInput.value || urlInput.value.includes('11434')) {
        urlInput.value = 'https://ollama.com/v1';
      }
    }
  }

  if (refresh) {
    const nameInput = document.getElementById('txt_model_name');
    if (nameInput) nameInput.value = '';
    const sel = document.getElementById('sel_model_preset');
    if (sel) sel.value = '';
    updateDynamicSnippets();
    refreshCurrentProviderModels();
  }
}

function setEndpointUrl(url) {
  const urlInp = document.getElementById('txt_endpoint_url');
  if (urlInp) urlInp.value = url;
  updateDynamicSnippets();
  refreshCurrentProviderModels();
}

function refreshCurrentProviderModels() {
  const prov = (currentProvider === 'ollama')
    ? (currentOllamaMode === 'cloud' ? 'ollama_cloud' : 'ollama_local')
    : currentProvider;
  const isHost = (prov === 'host');
  const btn = isHost ? document.getElementById('btnRefreshHostModels') : document.getElementById('btnRefreshModels');
  if (btn) {
    btn.textContent = '🔄 Refreshing...';
    btn.disabled = true;
  }

  if (activeModelFetchAbortController) {
    try {
      activeModelFetchAbortController.abort();
    } catch (_) {}
  }
  activeModelFetchAbortController = new AbortController();
  const currentSignal = activeModelFetchAbortController.signal;

  const timeoutId = setTimeout(() => {
    if (activeModelFetchAbortController && !currentSignal.aborted) {
      activeModelFetchAbortController.abort();
    }
  }, 5000);

  const rawUrl = document.getElementById('txt_endpoint_url')?.value.trim() || '';
  const key = document.getElementById('txt_api_key')?.value.trim() || '';

  let url = rawUrl;
  if (!url) {
    if (prov === 'ollama_cloud') url = 'https://ollama.com/v1';
    else if (prov === 'ollama_local') url = 'http://localhost:11434';
    else if (prov === 'lm_studio') url = 'http://localhost:1234/v1';
    else if (prov === 'vllm') url = 'http://localhost:8000/v1';
  }

  fetch(API_BASE + `/api/models?provider=${encodeURIComponent(prov)}&url=${encodeURIComponent(url)}&key=${encodeURIComponent(key)}`, {
    signal: currentSignal
  })
    .then(r => r.json())
    .then(data => {
      clearTimeout(timeoutId);
      if (currentSignal.aborted) return;
      if (isHost) {
        populateHostModels(data);
      } else {
        populateExternalModels(data);
      }
    })
    .catch(err => {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') return;
      showToast('Could not fetch models for ' + prov);
    })
    .finally(() => {
      clearTimeout(timeoutId);
      if (!currentSignal.aborted && btn) {
        btn.textContent = isHost ? '🔄 Refresh' : '🔄 Discover Models';
        btn.disabled = false;
      }
    });
}

function populateHostModels(data) {
  if (!data) return;
  if (data.host_name) {
    const hostNameEl = document.getElementById('host_detected_name');
    if (hostNameEl) hostNameEl.textContent = data.host_name;
  }
  const pri = data.primary_model || 'Active Chat Model (Auto)';
  const priEl = document.getElementById('host_primary_model');
  if (priEl) priEl.textContent = pri;

  const sel = document.getElementById('host_model_select');
  if (!sel) return;
  sel.innerHTML = '';
  const models = data.models || [];
  
  // Ensure default automatic option exists
  if (!models.some(m => m.id === 'auto')) {
    const autoOpt = document.createElement('option');
    autoOpt.value = 'auto';
    autoOpt.textContent = 'Automatic Host Delegation (Session Default)';
    sel.appendChild(autoOpt);
  }

  models.forEach(m => {
    if (m.id === 'auto') return;
    const opt = document.createElement('option');
    opt.value = m.id;
    if (m.is_primary || m.id === pri) {
      opt.textContent = m.label || (m.id + ' — [Primary Model in Chat]');
      opt.disabled = true;
      opt.style.color = 'var(--text-faint)';
    } else {
      opt.textContent = m.label || (m.id + ' (Host Delegation)');
    }
    sel.appendChild(opt);
  });

  const firstEnabled = Array.from(sel.options).find(o => !o.disabled);
  if (firstEnabled) sel.value = firstEnabled.value;
  showToast(`✅ Loaded host delegation (${data.host_name || 'Active IDE'})`);
}

function populateExternalModels(data) {
  const models = data.models || [];
  const datalist = document.getElementById('discovered_model_list');
  if (datalist) {
    datalist.innerHTML = '';
    models.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.label = m.label || m.id;
      datalist.appendChild(opt);
    });
  }

  const sel = document.getElementById('sel_model_preset');
  const nameInp = document.getElementById('txt_model_name');
  const currentVal = nameInp ? nameInp.value.trim() : '';

  if (sel) {
    const filterNote = (data.filtered_out_count && data.filtered_out_count > 0) 
      ? ` (${data.filtered_out_count} non-agent/media filtered)` 
      : '';
    sel.innerHTML = `<option value="">-- Choose from ${models.length} Discovered Agent Models${filterNote} --</option>`;
    
    // Group models by category
    const categories = {};
    models.forEach(m => {
      const cat = m.category || 'Discovered Models';
      if (!categories[cat]) categories[cat] = [];
      categories[cat].push(m);
    });

    Object.keys(categories).forEach(cat => {
      const group = document.createElement('optgroup');
      group.label = `─── ${cat} ───`;
      categories[cat].forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = m.label || m.id;
        group.appendChild(opt);
      });
      sel.appendChild(group);
    });

    // Add a dedicated custom model entry
    const customGroup = document.createElement('optgroup');
    customGroup.label = '─── Custom / Unlisted Model ───';
    const customOpt = document.createElement('option');
    customOpt.value = '__custom__';
    customOpt.textContent = '✍️ [Custom Model] Type any model name in the box below...';
    customGroup.appendChild(customOpt);
    sel.appendChild(customGroup);

    if (currentVal) {
      if (Array.from(sel.options).some(o => o.value === currentVal)) {
        sel.value = currentVal;
      } else {
        sel.value = '__custom__';
      }
    }
  }

  // Only fill input if currently empty
  if (models.length > 0) {
    if (nameInp && !nameInp.value) {
      nameInp.value = models[0].id;
      if (sel) sel.value = models[0].id;
    }
  }
  showToast(data.message || `Loaded ${models.length} models for ${data.provider_id || currentProvider}`);
}

function syncModelPreset() {
  const nameInp = document.getElementById('txt_model_name');
  const sel = document.getElementById('sel_model_preset');
  if (!nameInp || !sel) return;
  const typed = nameInp.value.trim();
  const matched = Array.from(sel.options).find(o => o.value === typed);
  if (matched) {
    sel.value = matched.value;
  } else if (typed) {
    const cust = Array.from(sel.options).find(o => o.value === '__custom__');
    if (cust) sel.value = '__custom__';
    else sel.value = "";
  } else {
    sel.value = "";
  }
  updateDynamicSnippets();
}

function loadHostInfo() {
  fetch(API_BASE + '/api/host_info')
    .then(r => r.json())
    .then(info => {
      if (info.host_name) {
        const hostNameEl = document.getElementById('host_detected_name');
        if (hostNameEl) hostNameEl.textContent = info.host_name;
      }
      if (info.primary_model) {
        const priEl = document.getElementById('host_primary_model');
        if (priEl) priEl.textContent = info.primary_model;
      }
      refreshCurrentProviderModels();
    })
    .catch(e => {
      console.warn('Could not load host info:', e);
      setupPreviewMode();
    });
}

function saveDelegationSettings() {
  const sel = document.getElementById('host_model_select');
  const model = sel ? sel.value : '';
  const sampling = document.getElementById('host_sampling_enabled')?.checked ?? true;
  const role = document.querySelector('input[name="aux_role"]:checked')?.value || 'adversarial_reviewer';

  fetch(API_BASE + '/api/save_delegation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      intra_host_sampling_enabled: sampling,
      model_hint: model,
      auxiliary_role: role,
    })
  })
  .then(r => r.json())
  .then(() => showToast('Host settings saved.'))
  .catch(() => showToast('Failed to save host settings.'));
}

function testHostSampling() {
  const sel = document.getElementById('host_model_select');
  const model = sel ? sel.value : '';
  showToast('Testing response with: ' + model + '...');
  fetch(API_BASE + '/api/test_host_sampling', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model_hint: model })
  })
  .then(r => r.json())
  .then(res => {
    if (res.success) {
      showToast('Response OK (' + (res.latency_ms || 0) + 'ms)');
    } else {
      showToast('Test failed: ' + (res.error || 'Unknown error'));
    }
  })
  .catch(err => showToast('Error: ' + err.message));
}

function onPresetSelected() {
  const sel = document.getElementById('sel_model_preset');
  const val = sel ? sel.value : '';
  const nameInp = document.getElementById('txt_model_name');
  if (!nameInp) return;
  if (val === '__custom__') {
    nameInp.placeholder = 'Type custom model name (e.g. qwen2.5-coder:14b, codellama, etc.)...';
    nameInp.focus();
    nameInp.select();
  } else if (val) {
    nameInp.value = val;
  }
  updateDynamicSnippets();
}

// --------------------------------------------------------------------------
// 4B. Dynamic Integration Script Generator (Python & JavaScript)
// --------------------------------------------------------------------------
function switchSnippetLang(lang) {
  activeSnippetLang = lang;
  document.getElementById('btnCodeLangPy')?.classList.toggle('active', lang === 'python');
  document.getElementById('btnCodeLangJs')?.classList.toggle('active', lang === 'javascript');
  updateDynamicSnippets();
}

function updateDynamicSnippets() {
  const snippetBox = document.getElementById('dynamic_snippet_box');
  if (!snippetBox) return;

  const model = document.getElementById('txt_model_name')?.value.trim() || 'target-model-name';
  let url = document.getElementById('txt_endpoint_url')?.value.trim() || 'http://localhost:11434';
  const key = document.getElementById('txt_api_key')?.value.trim() || 'sk-your-api-key';

  let completionsUrl = url.replace(/\/+$/, '');
  if (!completionsUrl.endsWith('/chat/completions')) {
    if (completionsUrl.endsWith('/v1')) completionsUrl += '/chat/completions';
    else if (!completionsUrl.endsWith('/v1/chat/completions')) completionsUrl += '/v1/chat/completions';
  }

  if (activeSnippetLang === 'python') {
    snippetBox.textContent = `# Python Integration Script for AOS:
import requests

response = requests.post(
    "${completionsUrl}",
    headers={
        "Authorization": "Bearer ${key}",
        "Content-Type": "application/json"
    },
    json={
        "model": "${model}",
        "messages": [{"role": "user", "content": "Ping AOS delegate test"}],
        "temperature": 0.2
    },
    timeout=30.0
)
print("Response:", response.json()["choices"][0]["message"]["content"])`;
  } else {
    snippetBox.textContent = `// JavaScript / Node.js Integration Script for AOS:
const response = await fetch("${completionsUrl}", {
  method: "POST",
  headers: {
    "Authorization": "Bearer ${key}",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    model: "${model}",
    messages: [{ role: "user", content: "Ping AOS delegate test" }],
    temperature: 0.2
  })
});
const data = await response.json();
console.log("Response:", data.choices[0].message.content);`;
  }
}

function activateCurrentProvider() {
  const model = document.getElementById('txt_model_name')?.value.trim() || '';
  const rawUrl = document.getElementById('txt_endpoint_url')?.value.trim() || '';
  const key = document.getElementById('txt_api_key')?.value.trim() || '';
  const prov = (currentProvider === 'ollama')
    ? (currentOllamaMode === 'cloud' ? 'ollama_cloud' : 'ollama_local')
    : currentProvider;

  let url = rawUrl;
  if (!url) {
    if (prov === 'ollama_cloud') url = 'https://ollama.com/v1';
    else if (prov === 'ollama_local') url = 'http://localhost:11434';
    else if (prov === 'lm_studio') url = 'http://localhost:1234/v1';
    else if (prov === 'vllm') url = 'http://localhost:8000/v1';
  }

  fetch(API_BASE + '/api/activate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      provider: prov,
      model: model,
      url: url,
      key: key
    })
  })
  .then(r => r.json())
  .then(() => {
    const chk = document.getElementById('chk_assistant_enabled');
    if (chk) chk.checked = true;
    currentModes.assistant_llm_enabled = true;
    showToast('Activated model: ' + model);
  })
  .catch(() => showToast('Failed to activate provider.'));
}

function testConnection() {
  const fb = document.getElementById('test_feedback');
  if (fb) {
    fb.className = 'diag-card diag-warning';
    fb.style.display = 'block';
    fb.innerHTML = '<div><span class="pulse-dot"></span> <strong>Testing connection to ' + currentProvider + '...</strong></div>';
  }

  const model = document.getElementById('txt_model_name')?.value.trim() || '';
  const rawUrl = document.getElementById('txt_endpoint_url')?.value.trim() || '';
  const key = document.getElementById('txt_api_key')?.value.trim() || '';
  const prov = (currentProvider === 'ollama')
    ? (currentOllamaMode === 'cloud' ? 'ollama_cloud' : 'ollama_local')
    : currentProvider;

  let url = rawUrl;
  if (!url) {
    if (prov === 'ollama_cloud') url = 'https://ollama.com/v1';
    else if (prov === 'ollama_local') url = 'http://localhost:11434';
    else if (prov === 'lm_studio') url = 'http://localhost:1234/v1';
    else if (prov === 'vllm') url = 'http://localhost:8000/v1';
  }

  fetch(API_BASE + '/api/test', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      provider: prov,
      model: model,
      url: url,
      key: key
    })
  })
  .then(r => r.json())
  .then(res => {
    if (!fb) return;
    if (res.success) {
      fb.className = 'diag-card diag-success';
      fb.style.display = 'block';
      let countText = '';
      if (res.installed_models && res.installed_models.length > 0) {
        countText = ` (${res.installed_models.length} agent models available`;
        if (res.filtered_out_count && res.filtered_out_count > 0) {
          countText += `, ${res.filtered_out_count} non-agent/media filtered`;
        }
        countText += ')';
      }
      fb.innerHTML = `
        <div><span class="diag-badge" style="background:var(--success); color:#090d16;">Connected</span> <strong>Connection Verified</strong> in ${res.latency_ms || 0}ms${countText}</div>
        <div style="font-size:11.5px; margin-top:5px; opacity:0.9;">${res.message || 'Provider is online and authenticated for assistant tasks.'}</div>
      `;
      // Automatically refresh models so the dropdown instantly populates with the verified models
      refreshCurrentProviderModels();
    } else {
      const errCls = (res.error_class || 'error').toUpperCase().replace(/_/g, ' ');
      const fix = res.suggested_fix || 'Verify endpoint URL and API credentials in your provider dashboard.';
      const isQuota = (res.error_class === 'quota_exhausted');
      fb.className = `diag-card ${isQuota ? 'diag-warning' : 'diag-error'}`;
      fb.style.display = 'block';
      fb.innerHTML = `
        <div><span class="diag-badge" style="background:${isQuota ? 'var(--warning)' : 'var(--danger)'}; color:#090d16;">${errCls}</span> <strong>${res.error || 'Connection Failed'}</strong></div>
        <div class="diag-fix">💡 <strong>Actionable Fix:</strong> ${fix}</div>
      `;
    }
  })
  .catch(err => {
    if (fb) {
      fb.className = 'diag-card diag-error';
      fb.style.display = 'block';
      fb.innerHTML = `
        <div><span class="diag-badge" style="background:var(--danger); color:#090d16;">NETWORK ERROR</span> <strong>Failed to reach local settings server</strong></div>
        <div class="diag-fix">💡 <strong>Actionable Fix:</strong> Ensure AOS background service is running on 127.0.0.1:4141. (${err.message})</div>
      `;
    }
  });
}

// --------------------------------------------------------------------------
// 5. Projects & Live Execution Review (ACTIVE_MISSION.md Viewer)
// --------------------------------------------------------------------------
function loadProjects() {
  const btn = document.getElementById('btnReloadProgress');
  if (btn) btn.textContent = '🔄 Reloading...';

  fetch(API_BASE + '/api/projects')
    .then(r => r.json())
    .then(data => {
      registeredProjects = data.projects || [];
      renderProjectsList();
      showToast(`Refreshed projects list (${registeredProjects.length} workspace${registeredProjects.length === 1 ? '' : 's'})`);
    })
    .catch(err => {
      console.warn('Failed to load projects:', err);
      if (!registeredProjects || registeredProjects.length === 0) {
        setupPreviewMode();
      }
      showToast('Projects loaded (Preview Mode)');
    })
    .finally(() => {
      if (btn) btn.textContent = '🔄 Reload Progress';
    });
}

function renderProjectsList() {
  const sel = document.getElementById('sel_project_picker');
  if (!sel) return;
  sel.innerHTML = '';

  if (registeredProjects.length === 0) {
    sel.innerHTML = '<option value="">No registered projects found</option>';
    renderSelectedProject(null);
    return;
  }

  registeredProjects.forEach((p, idx) => {
    const opt = document.createElement('option');
    opt.value = p.path;
    const folderName = p.name || (p.path ? p.path.split(/[\\/]/).filter(Boolean).pop() : 'Project');
    opt.textContent = `${folderName} — ${p.path}`;
    if (idx === 0) opt.selected = true;
    sel.appendChild(opt);
  });

  selectedProjectPath = registeredProjects[0].path;
  renderSelectedProject(registeredProjects[0]);
}

function onProjectChanged() {
  const sel = document.getElementById('sel_project_picker');
  if (!sel) return;
  selectedProjectPath = sel.value;
  const proj = registeredProjects.find(p => p.path === selectedProjectPath);
  renderSelectedProject(proj || null);
}

function updateQuotaTelemetryStrip(telemetry) {
  if (!telemetry) return;
  const quotaEl = document.getElementById('metric_host_quota');
  const sparedEl = document.getElementById('metric_host_spared');
  const runwayEl = document.getElementById('metric_runway');
  const tokensEl = document.getElementById('metric_tokens_saved');

  if (telemetry.active_host) {
    const h = telemetry.active_host;
    if (quotaEl) {
      const pct = h.quota_remaining_pct !== undefined ? h.quota_remaining_pct : 100;
      let resetInfo = '';
      if (h.quota_reset_time) {
        try {
          const d = new Date(h.quota_reset_time);
          resetInfo = ` (Reset: ${d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})})`;
        } catch (_) {}
      }
      quotaEl.textContent = `${h.host_name}: ${pct}% Quota${resetInfo}`;
    }
  }
  if (sparedEl) {
    const count = telemetry.host_turns_spared || 0;
    const rate = telemetry.host_protection_rate_pct || 0;
    sparedEl.textContent = `${count} Spared (${rate}% Protection)`;
  }
  if (runwayEl) {
    const mult = telemetry.runway_multiplier || 1.0;
    runwayEl.textContent = `${mult}x Extended`;
  }
  if (tokensEl) {
    const saved = (telemetry.cumulative_tokens_saved || 0).toLocaleString();
    const pct = telemetry.avg_savings_pct || 0;
    tokensEl.textContent = `${saved} Tokens (${pct}% Avg)`;
  }
}

function renderSelectedProject(p) {
  const detailsBox = document.getElementById('project_details_box');
  const missionBox = document.getElementById('live_mission_container');
  if (!p) {
    if (detailsBox) detailsBox.style.display = 'none';
    if (missionBox) missionBox.style.display = 'none';
    return;
  }

  if (detailsBox) detailsBox.style.display = 'block';
  if (missionBox) missionBox.style.display = 'block';

  // Stats
  document.getElementById('stat_disk_total').textContent = p.disk?.total_formatted || '0 B';
  document.getElementById('stat_cache_size').textContent = p.disk?.cache_formatted || '0 B';
  document.getElementById('stat_tokens_saved').textContent = (p.telemetry?.cumulative_tokens_saved || 0).toLocaleString();
  document.getElementById('stat_savings_pct').textContent = (p.telemetry?.avg_savings_pct || 0) + '%';
  const hostSparedEl = document.getElementById('stat_host_spared');
  if (hostSparedEl) {
    const turns = p.telemetry?.host_turns_spared || 0;
    const rate = p.telemetry?.host_protection_rate_pct || 0;
    hostSparedEl.textContent = `${turns} (${rate}%)`;
  }

  // Update Dual-Dimension Host Quota & Telemetry Strip
  if (p.telemetry) {
    updateQuotaTelemetryStrip(p.telemetry);
  }

  // Live Mission / Execution Review File Preview
  const mission = p.live_mission;
  currentLiveMission = mission;
  const missionContent = document.getElementById('mission_content');
  const missionEmpty = document.getElementById('mission_empty');
  const statusBadge = document.getElementById('badge_mission_status');
  const statusDesc = document.getElementById('desc_mission_status');
  const btnClear = document.getElementById('btnClearMission');

  if (mission && mission.has_mission) {
    if (missionContent) missionContent.style.display = 'block';
    if (missionEmpty) missionEmpty.style.display = 'none';

    // State Badge & Rationale
    const state = mission.mission_state || 'idle';
    if (state === 'executing') {
      if (statusBadge) {
        statusBadge.className = 'badge badge-running';
        statusBadge.innerHTML = '<span class="pulse-dot"></span> In Progress (Executing Now)';
      }
      if (statusDesc) statusDesc.textContent = 'Active task executing right now. Steps and architecture reviews are streaming dynamically.';
      if (btnClear) btnClear.style.display = 'none';
    } else if (state === 'completed') {
      if (statusBadge) {
        statusBadge.className = 'badge badge-completed';
        statusBadge.textContent = '✔ Execution Completed';
      }
      if (statusDesc) statusDesc.textContent = 'Previous mission finished and verified. Review report and architecture diagram available below:';
      if (btnClear) btnClear.style.display = 'inline-block';
    } else {
      if (statusBadge) {
        statusBadge.className = 'badge badge-idle';
        statusBadge.textContent = '⏸ Idle (Saved Snapshot)';
      }
      if (statusDesc) statusDesc.textContent = 'No task actively executing now. Last recorded execution snapshot is loaded below:';
      if (btnClear) btnClear.style.display = 'inline-block';
    }

    document.getElementById('lbl_mission_objective').textContent = mission.objective || 'Mission Task';
    const timeEl = document.getElementById('lbl_mission_timestamp');
    if (timeEl) {
      timeEl.textContent = `State: ${state.toUpperCase()} • Last updated: ${mission.updated_at ? new Date(mission.updated_at).toLocaleTimeString() : 'Recent'}`;
    }

    document.getElementById('lbl_mission_progress').textContent = `${mission.done_steps || 0}/${mission.total_steps || 0} steps (${mission.progress_pct || 0}%)`;
    document.getElementById('bar_mission_progress').style.width = (mission.progress_pct || 0) + '%';

    // Checklist
    const stepsList = document.getElementById('mission_steps_list');
    if (stepsList) {
      stepsList.innerHTML = '';
      (mission.steps || []).forEach(s => {
        const item = document.createElement('div');
        item.className = 'step-item ' + (s.status || 'pending');
        item.innerHTML = `
          <span>${s.checkbox || '○'}</span>
          <span style="flex:1;">${s.title}</span>
          <span class="step-badge">${s.status}</span>
        `;
        stepsList.appendChild(item);
      });
    }

    // Markdown Review Formatting
    const mdRaw = mission.human_markdown || mission.compact_delta_summary || 'No review markdown report available.';
    const mdBox = document.getElementById('mission_markdown_preview');
    if (mdBox) mdBox.textContent = mdRaw;
    const mdFormatted = document.getElementById('mission_markdown_formatted');
    if (mdFormatted) mdFormatted.innerHTML = renderMarkdownToHtml(mdRaw);

    // Flowchart Diagram Rendering (Real Graphical SVG)
    const flowText = mission.mermaid_flowchart || '';
    renderFlowchartDiagram(flowText);

  } else {
    if (missionContent) missionContent.style.display = 'none';
    if (missionEmpty) missionEmpty.style.display = 'block';
    if (statusBadge) {
      statusBadge.className = 'badge badge-idle';
      statusBadge.textContent = 'Idle';
    }
    if (statusDesc) statusDesc.textContent = 'Real-time step tracking and architecture review outside your chat context window.';
    if (btnClear) btnClear.style.display = 'none';
  }
}

function renderMarkdownToHtml(md) {
  if (!md) return '<p style="color:var(--text-muted);">No review report available.</p>';
  let html = md
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Fenced code blocks
  html = html.replace(/```([a-z]*)\n([\s\S]*?)```/g, (m, lang, code) => {
    return `<pre><code>${code.trim()}</code></pre>`;
  });

  // Headers
  html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
  html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
  html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

  // Bold & Italic
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Checkboxes
  html = html.replace(/^[*-] \[x\] (.*$)/gim, '<div style="display:flex; align-items:center; gap:6px; margin:4px 0;"><span style="color:var(--success);">✔</span> <span>$1</span></div>');
  html = html.replace(/^[*-] \[ \] (.*$)/gim, '<div style="display:flex; align-items:center; gap:6px; margin:4px 0;"><span style="color:var(--text-muted);">○</span> <span>$1</span></div>');

  // Bullets
  html = html.replace(/^[*-] (.*$)/gim, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)/gims, '<ul>$1</ul>');

  // Line breaks
  html = html.replace(/\n\n/g, '<br><br>');
  return html;
}

function renderFlowchartDiagram(flowchartText) {
  const canvas = document.getElementById('mission_flowchart_canvas');
  const rawBox = document.getElementById('mission_flowchart_preview');
  if (rawBox) rawBox.textContent = flowchartText || 'No flowchart recorded.';
  if (!canvas) return;

  if (!flowchartText || !flowchartText.trim()) {
    canvas.innerHTML = '<div style="color:var(--text-muted); font-size:12.5px;">No architecture flowchart recorded for this task.</div>';
    return;
  }

  // Attempt 1: Native Mermaid rendering if available
  if (window.mermaid) {
    try {
      mermaid.initialize({ startOnLoad: false, theme: 'dark', securityLevel: 'loose' });
      const uniqueId = 'svg_mermaid_' + Math.floor(Math.random() * 1000000);
      mermaid.render(uniqueId, flowchartText)
        .then(({ svg }) => {
          canvas.innerHTML = svg;
        })
        .catch(err => {
          console.warn('Mermaid render fallback:', err);
          canvas.innerHTML = renderFallbackSvg(flowchartText);
        });
      return;
    } catch (e) {
      console.warn('Mermaid execution fallback:', e);
    }
  }

  // Attempt 2: Visual SVG Fallback
  canvas.innerHTML = renderFallbackSvg(flowchartText);
}

function renderFallbackSvg(flowchartText) {
  const lines = flowchartText.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('flowchart'));
  const steps = [];
  lines.forEach(line => {
    const match = line.match(/([A-Za-z0-9_]+)\s*(\[|\{)(.*?)(\]|\})\s*(?:-->\s*(?:\|([^|]+)\|)?\s*([A-Za-z0-9_]+))?/);
    if (match) {
      const id = match[1];
      const isDecision = match[2] === '{';
      const label = match[3];
      const edgeLabel = match[5] || '';
      steps.push({ id, label, isDecision, edgeLabel });
    }
  });

  if (steps.length === 0) {
    return `<div style="padding:16px; width:100%;"><pre style="color:var(--accent); font-family:monospace; font-size:12px;">${flowchartText}</pre></div>`;
  }

  const boxWidth = 320;
  const boxHeight = 44;
  const gap = 36;
  const svgHeight = steps.length * (boxHeight + gap) + 40;
  const svgWidth = 440;
  const centerX = svgWidth / 2;

  let svgElements = '';
  steps.forEach((s, idx) => {
    const y = 26 + idx * (boxHeight + gap);
    const fill = s.isDecision ? '#1e293b' : '#0f172a';
    const stroke = s.isDecision ? '#f59e0b' : '#38bdf8';
    const rx = s.isDecision ? 4 : 8;

    svgElements += `
      <g>
        <rect x="${centerX - boxWidth/2}" y="${y}" width="${boxWidth}" height="${boxHeight}" rx="${rx}" fill="${fill}" stroke="${stroke}" stroke-width="1.5" />
        <text x="${centerX}" y="${y + boxHeight/2 + 4}" fill="#f8fafc" font-size="12" font-family="-apple-system, BlinkMacSystemFont, Segoe UI, sans-serif" font-weight="600" text-anchor="middle">${s.label.slice(0, 42)}</text>
      </g>
    `;

    if (idx < steps.length - 1) {
      const nextY = y + boxHeight;
      const targetY = nextY + gap;
      svgElements += `
        <g>
          <line x1="${centerX}" y1="${nextY}" x2="${centerX}" y2="${targetY - 5}" stroke="#38bdf8" stroke-width="2" />
          <polygon points="${centerX},${targetY} ${centerX - 4},${targetY - 6} ${centerX + 4},${targetY - 6}" fill="#38bdf8" />
          ${s.edgeLabel ? `<text x="${centerX + 12}" y="${nextY + gap/2 + 3}" fill="#94a3b8" font-size="10.5" font-family="sans-serif">${s.edgeLabel}</text>` : ''}
        </g>
      `;
    }
  });

  return `
    <svg width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}" xmlns="http://www.w3.org/2000/svg" style="background:#090d16; border-radius:8px; border:1px solid rgba(255,255,255,0.08);">
      ${svgElements}
    </svg>
  `;
}

function switchReviewTab(tab) {
  activeReviewTab = tab;
  const mdContainer = document.getElementById('mission_md_container');
  const flowContainer = document.getElementById('mission_flow_container');
  const btnMd = document.getElementById('btnTabMdReview');
  const btnFlow = document.getElementById('btnTabFlowReview');

  if (tab === 'flow') {
    if (mdContainer) mdContainer.style.display = 'none';
    if (flowContainer) flowContainer.style.display = 'block';
    if (btnMd) btnMd.classList.remove('active');
    if (btnFlow) btnFlow.classList.add('active');
    if (currentLiveMission && currentLiveMission.mermaid_flowchart) {
      renderFlowchartDiagram(currentLiveMission.mermaid_flowchart);
    }
  } else {
    if (mdContainer) mdContainer.style.display = 'block';
    if (flowContainer) flowContainer.style.display = 'none';
    if (btnMd) btnMd.classList.add('active');
    if (btnFlow) btnFlow.classList.remove('active');
  }
}

function toggleRawView() {
  isRawReviewMode = !isRawReviewMode;
  const mdFormatted = document.getElementById('mission_markdown_formatted');
  const mdRaw = document.getElementById('mission_markdown_preview');
  const flowCanvas = document.getElementById('mission_flowchart_canvas');
  const flowRaw = document.getElementById('mission_flowchart_preview');

  if (activeReviewTab === 'md') {
    if (mdFormatted) mdFormatted.style.display = isRawReviewMode ? 'none' : 'block';
    if (mdRaw) mdRaw.style.display = isRawReviewMode ? 'block' : 'none';
  } else {
    if (flowCanvas) flowCanvas.style.display = isRawReviewMode ? 'none' : 'flex';
    if (flowRaw) flowRaw.style.display = isRawReviewMode ? 'block' : 'none';
  }

  const btn = document.getElementById('btnToggleRaw');
  if (btn) btn.textContent = isRawReviewMode ? '🖼️ Visual View' : '👁️ Toggle Raw / Visual';
}

function copyActiveReviewContent() {
  const targetId = activeReviewTab === 'flow' ? 'mission_flowchart_preview' : 'mission_markdown_preview';
  copyCode(targetId);
}

function clearMission() {
  if (!selectedProjectPath) return;
  fetch(API_BASE + '/api/clear_mission', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: selectedProjectPath })
  })
  .then(r => r.json())
  .then(() => {
    showToast('Mission archived. Workspace review is now clean.');
    loadProjects();
  })
  .catch(() => showToast('Failed to clear mission.'));
}

function cleanCurrentProjectCache() {
  if (!selectedProjectPath) return;
  fetch(API_BASE + '/api/clean_project_cache', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path: selectedProjectPath })
  })
  .then(r => r.json())
  .then(res => {
    showToast(`Cleaned ${res.cleaned_items || 0} items (${res.freed_bytes_formatted || '0 B'} freed).`);
    loadProjects();
  })
  .catch(() => showToast('Failed to clean project cache.'));
}

function runAutomatedSetup() {
  const btn = document.getElementById('btnAutoSetup');
  const fb = document.getElementById('setup_feedback');
  if (btn) {
    btn.textContent = '⚡ Configuring...';
    btn.disabled = true;
  }
  if (fb) {
    fb.style.display = 'block';
    fb.className = 'diag-card diag-warning';
    fb.innerHTML = '<span class="pulse-dot"></span> Detecting IDEs and injecting MCP configuration...';
  }

  fetch(API_BASE + '/api/run_setup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ workspace_path: selectedProjectPath || '' })
  })
  .then(r => r.json())
  .then(res => {
    if (!fb) return;
    if (res.success) {
      const files = res.injected_files || [];
      fb.className = 'diag-card diag-success';
      fb.innerHTML = `
        <div><strong>✅ Successfully Injected MCP Configuration (${files.length} hosts configured):</strong></div>
        <ul style="margin-top:6px; padding-left:18px; font-size:11.5px; line-height:1.6;">
          ${files.map(f => `<li><code>${f}</code></li>`).join('')}
        </ul>
        <div style="font-size:11px; margin-top:6px; color:#a7f3d0;">AOS MCP is now registered and discovered across your editors.</div>
      `;
      showToast(`Injected MCP into ${files.length} IDE configurations.`);
    } else {
      fb.className = 'diag-card diag-error';
      fb.innerHTML = `<div><strong>❌ Setup Failed:</strong> ${res.error || 'Unknown error'}</div>`;
    }
  })
  .catch(err => {
    if (fb) {
      fb.className = 'diag-card diag-error';
      fb.innerHTML = `<div><strong>❌ Error:</strong> ${err.message}. If server is offline, run <code>aos setup</code> in terminal.</div>`;
    }
  })
  .finally(() => {
    if (btn) {
      btn.textContent = '⚡ Auto-Configure All IDEs';
      btn.disabled = false;
    }
  });
}

function copyText(str) {
  navigator.clipboard.writeText(str).then(() => showToast('Copied: ' + str));
}

// --------------------------------------------------------------------------
// 6. Helpers
// --------------------------------------------------------------------------
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 3000);
}

function copyCode(elemId) {
  const txt = document.getElementById(elemId)?.textContent;
  if (!txt) return;
  navigator.clipboard.writeText(txt).then(() => showToast('Copied to clipboard!'));
}

function loadMcpConfig() {
  fetch(API_BASE + '/api/mcp_config')
    .then(r => r.json())
    .then(res => {
      const el = document.getElementById('codeMcpConfig');
      if (el && res.formatted) {
        el.textContent = res.formatted;
      }
    })
    .catch(() => {});
}

// Explicit button event bindings
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btnRefreshHostModels')?.addEventListener('click', refreshCurrentProviderModels);
  document.getElementById('btnRefreshModels')?.addEventListener('click', refreshCurrentProviderModels);
  document.getElementById('btnReloadProgress')?.addEventListener('click', loadProjects);
});

// Initialize on Load
loadStatus();
loadMcpConfig();
